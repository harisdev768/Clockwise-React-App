<?php
// App configuration

$host = 'localhost';
$db   = 'clockwise';
$user = 'admin_u_rw';
$pass = 'Loc@lhost';


// Base URL for API (optional, useful if you're building links)
define('BASE_URL', 'http://clockwise.local/api-2/');